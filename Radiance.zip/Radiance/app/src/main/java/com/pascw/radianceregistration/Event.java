package com.pascw.radianceregistration;

public class Event {
    private int image;
    private String name;

    public Event() {

    }

    public Event(String name, int image) {
        this.name = name;
        this.image = image;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
