package com.pascw.radianceregistration;

public class Config {

    public static final String EMAIL ="pasc.radiance@gmail.com"; //your-gmail-username   acm.pict@gmail.com
    public static final String PASSWORD ="pascw@1415";
}
